<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Camp;


class CampsController extends Controller
{
    public function blog()
    {
        $featuredBlogs = Blog::rand(3)->get();
        return view('Blog.blog',compact('featuredBlogs'));
    }
    public function show(Camp $slug)
    {
        return view('Camp.show',compact('slug'));
    }
}
